## User Stories
- As a user, I don't have an enough time to go to the carpenter every time I want to fix something in my house so it will help me a lot to have a person who can come to me and fix all things need to to be fixed in my home.
- As a user, I am exposed all the time to getting a broken wood or things need to painted and it's very great to have a service in my palce.
- As a user, In case my kitchen for example need some fixes, It would be great to have a service that is delivered directly to my home.
- As a user, I don't have a good experience with woods, so I need someone to help me to get to know my stuff more and what it needs for the periodic maintenance and how to keep it longer.- As a user, I want to leave my feadback for the provider of the service.

### Schema

<br>

![schema](prep/schema.png)

<br>

### Wireframes

<br>
[wireframe1](https://miro.com/welcomeonboard/T0lqZmI4Uk1jZUxBYktQMWtKQUpiZjRoWmhaYTduOTlUc1ZuQ05UVWNWU3BsTHI2dXJRMHlxMk9vVlNybHBLSnwzMDc0NDU3MzY1OTY5ODcyMzYy?invite_link_id=995199574297)

